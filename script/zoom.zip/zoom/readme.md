## About Zoom

A small jQuery plugin for zooming images on mouseover or mousedown. See the [project page](http://jacklmoore.com/zoom/) for documentation and a demonstration.  Released under the [MIT license](http://www.opensource.org/licenses/mit-license.php).
 
## Changelog:

### Version 1.3 - Dec. 21 2011
* Added 'callback' property that will execute a callback function once the image has loaded.
* Fixed a bug relating to the 'grab' property

### Version 1.2 - Nov. 15 2011
* Fixed a positioning bug

### Version 1.1 - Nov. 15 2011
* Added 'grab' property

### Version 1.0 - Nov. 11 2011
* First release